require("dotenv").config();
const express=require("express");
const crypto=require("crypto");
const Razorpay=require("razorpay");

const app=express();
app.use(express.json());
app.use(express.static("public"));

const keyId=process.env.RAZORPAY_KEY_ID;
const keySecret=process.env.RAZORPAY_KEY_SECRET;
if(!keyId || !keySecret){
  console.warn("Missing RAZORPAY_KEY_ID / RAZORPAY_KEY_SECRET in .env");
}
const razorpay=new Razorpay({key_id:keyId,key_secret:keySecret});

app.post("/api/create-order",async(req,res)=>{
  try{
    const amount=Number(req.body.amount);
    if(!Number.isInteger(amount)||amount<=0) return res.status(400).json({error:"Invalid amount"});
    const receipt="FFD"+Date.now();
    const order=await razorpay.orders.create({
      amount,currency:"INR",receipt,notes:{
        customer_name:String(req.body.name||"").slice(0,100),
        customer_phone:String(req.body.phone||"").slice(0,30)
      }
    });
    res.json({order_id:order.id,amount:order.amount,currency:order.currency,receipt,key_id:keyId});
  }catch(e){
    console.error(e);
    res.status(500).json({error:"Unable to create Razorpay order"});
  }
});

app.post("/api/verify-payment",(req,res)=>{
  try{
    const {razorpay_order_id,razorpay_payment_id,razorpay_signature}=req.body;
    if(!razorpay_order_id||!razorpay_payment_id||!razorpay_signature) return res.status(400).json({verified:false});
    const expected=crypto.createHmac("sha256",keySecret)
      .update(razorpay_order_id+"|"+razorpay_payment_id).digest("hex");
    const a=Buffer.from(expected,"utf8"),b=Buffer.from(razorpay_signature,"utf8");
    const verified=a.length===b.length && crypto.timingSafeEqual(a,b);
    res.status(verified?200:400).json({verified});
  }catch(e){
    console.error(e);
    res.status(400).json({verified:false});
  }
});

const port=process.env.PORT||3000;
app.listen(port,()=>console.log(`Fast Food Delivery running at http://localhost:${port}`));
