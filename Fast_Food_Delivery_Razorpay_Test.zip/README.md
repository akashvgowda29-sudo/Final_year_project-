# Fast Food Delivery — Razorpay Test Integration

This package adds Razorpay Standard Checkout in **Test Mode** to the Fast Food Delivery website.

## Setup

1. Install Node.js.
2. In the Razorpay Dashboard, switch to **Test Mode** and generate API keys.
3. Copy `.env.example` to `.env`.
4. Put your TEST Key ID and TEST Key Secret into `.env`.
5. Run:
   npm install
   npm start
6. Open:
   http://localhost:3000

## Test payment

The Razorpay checkout is opened from the checkout button. Test Mode does not move real money. Use the test payment credentials shown in the Razorpay Dashboard/docs.

## Security

- The Key Secret stays in `.env` on the server and is never sent to the browser.
- The server creates the Razorpay order.
- The server verifies the returned payment signature using HMAC-SHA256 and a timing-safe comparison.
- For production, add a database, order status management, webhook verification, authentication, HTTPS and proper fulfilment logic.

Official Razorpay documentation:
https://razorpay.com/docs/developer-tools/integrations/standard-checkout/
